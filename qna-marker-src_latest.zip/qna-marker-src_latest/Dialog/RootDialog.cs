// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.BotBuilderSamples.Utils;
using Microsoft.Extensions.Configuration;

using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;

namespace Microsoft.BotBuilderSamples.Dialog
{
    /// <summary>
    /// This is an example root dialog. Replace this with your applications.
    /// </summary>
    public class RootDialog : ComponentDialog
    {
        /// <summary>
        /// QnA Maker initial dialog
        /// </summary>
        private const string InitialDialog = "initial-dialog";

        /// <summary>
        /// Initializes a new instance of the <see cref="RootDialog"/> class.
        /// </summary>
        /// <param name="services">Bot Services.</param>
        public RootDialog(IBotServices services, IConfiguration configuration) : base("root")
        {
            AddDialog(new OAuthPrompt(
            nameof(OAuthPrompt),
            new OAuthPromptSettings
            {
            ConnectionName = configuration["ConnectionName"],
            Text = "Please Sign In",
            Title = "Sign In",
            Timeout = 300, // User has 5 minutes to login (1000 * 60 * 5)
            }));

            AddDialog(new QnAMakerBaseDialog(services));

            //AddDialog(new WaterfallDialog(InitialDialog).AddStep(InitialStepAsync));

            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), new WaterfallStep[]
            {
                PromptStepAsync,
                LoginStepAsync,
                //CommandStepAsync,
                //ProcessStepAsync,
                InitialStepAsync
            }));


            // The initial child Dialog to run.
            //InitialDialogId = InitialDialog;
            InitialDialogId = nameof(WaterfallDialog);
        }

        private async Task<DialogTurnResult> PromptStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.BeginDialogAsync(nameof(OAuthPrompt), null, cancellationToken);
        }

        private async Task<DialogTurnResult> LoginStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Get the token from the previous step. Note that we could also have gotten the
            // token directly from the prompt itself. There is an example of this in the next method.
            var tokenResponse = (TokenResponse)stepContext.Result;
            //var tokenResponse = (TokenResponse)null;
            //var userProfileName = (string)stepContext.Result;
            if (tokenResponse != null)
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("You are now logged in. Type 'help' to get started."), cancellationToken);
                //await stepContext.Context.SendActivityAsync(MessageFactory.Text(string.Format("You are now logged in. Token is {1}. Type 'help' to get started.", userProfileName)), cancellationToken);
                //await stepContext.Context.SendActivityAsync(MessageFactory.Text(String.Format("Hi {0}. How can I help you today?", userProfile.Name)), cancellationToken);
                //return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Would you like to do? (type 'me', 'send <EMAIL>' or 'recent')") }, cancellationToken);
                //return await stepContext.BeginDialogAsync(nameof(QnAMakerBaseDialog), dialogOptions, cancellationToken);
                //return await stepContext.BeginDialogAsync(nameof(WaterfallDialog), cancellationToken);
                return await stepContext.ContinueDialogAsync();
            }
           
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("Login was not successful please try again. Type 'help' to get started."), cancellationToken);
                return await stepContext.EndDialogAsync();
            
            
        }

        private async Task<DialogTurnResult> CommandStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            stepContext.Values["command"] = stepContext.Result;

            // Call the prompt again because we need the token. The reasons for this are:
            // 1. If the user is already logged in we do not need to store the token locally in the bot and worry
            // about refreshing it. We can always just call the prompt again to get the token.
            // 2. We never know how long it will take a user to respond. By the time the
            // user responds the token may have expired. The user would then be prompted to login again.
            //
            // There is no reason to store the token locally in the bot because we can always just call
            // the OAuth prompt to get the token or get a new token if needed.
            return await stepContext.BeginDialogAsync(nameof(OAuthPrompt), null, cancellationToken);
        }

        private async Task<DialogTurnResult> ProcessStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (stepContext.Result != null)
            {
                // We do not need to store the token in the bot. When we need the token we can
                // send another prompt. If the token is valid the user will not need to log back in.
                // The token will be available in the Result property of the task.
                var tokenResponse = stepContext.Result as TokenResponse;

                // If we have the token use the user is authenticated so we may use it to make API calls.
                if (tokenResponse?.Token != null)
                {
                    var parts = ((string)stepContext.Values["command"] ?? string.Empty).ToLowerInvariant().Split(' ');

                    var command = parts[0];
                    /*
                    if (command == "me")
                    {
                        await OAuthHelpers.ListMeAsync(stepContext.Context, tokenResponse);
                    }
                    else if (command.StartsWith("send"))
                    {
                        await OAuthHelpers.SendMailAsync(stepContext.Context, tokenResponse, parts[1]);
                    }
                    else if (command.StartsWith("recent"))
                    {
                        await OAuthHelpers.ListRecentMailAsync(stepContext.Context, tokenResponse);
                    }
                    else
                    {
                        await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Your token is: {tokenResponse.Token}"), cancellationToken);
                    }
                    */
                    await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Type Hi to begin. Your token is: {tokenResponse.Token}"), cancellationToken);
                }
            }
            else
            {
                await stepContext.Context.SendActivityAsync(MessageFactory.Text("We couldn't log you in. Please try again later by typing login."), cancellationToken);
            }

            return await stepContext.EndDialogAsync(cancellationToken: cancellationToken);
        }

        private async Task<DialogTurnResult> InitialStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            // Set values for generate answer options.
            var qnamakerOptions = new QnAMakerOptions
            {
                ScoreThreshold = QnAMakerBaseDialog.DefaultThreshold,
                Top = QnAMakerBaseDialog.DefaultTopN,
                Context = new QnARequestContext()
            };

            // Set values for dialog responses.
            var qnaDialogResponseOptions = new QnADialogResponseOptions
            {
                NoAnswer = QnAMakerBaseDialog.DefaultNoAnswer,
                ActiveLearningCardTitle = QnAMakerBaseDialog.DefaultCardTitle,
                CardNoMatchText = QnAMakerBaseDialog.DefaultCardNoMatchText,
                CardNoMatchResponse = QnAMakerBaseDialog.DefaultCardNoMatchResponse
            };

            var dialogOptions = new Dictionary<string, object>
            {
                [QnAMakerBaseDialog.QnAOptions] = qnamakerOptions,
                [QnAMakerBaseDialog.QnADialogResponseOptions] = qnaDialogResponseOptions
            };

            return await stepContext.BeginDialogAsync(nameof(QnAMakerBaseDialog), dialogOptions, cancellationToken);
        }
    }
}
